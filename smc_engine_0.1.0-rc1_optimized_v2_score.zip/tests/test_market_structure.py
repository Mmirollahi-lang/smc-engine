from core.market_structure import Candle, MarketStructureEngine


def make_candles(closes):
    candles = []
    for i, close in enumerate(closes):
        candles.append(
            Candle(
                timestamp=f"2026-01-01T{i:02d}:00:00",
                open=close,
                high=close + 1,
                low=close - 1,
                close=close,
            )
        )
    return candles


def test_insufficient_data():
    engine = MarketStructureEngine()
    result = engine.analyze(make_candles([100, 101, 102]))
    assert result.bias == "NO_TRADE"


def test_result_is_structured():
    engine = MarketStructureEngine()
    candles = make_candles(
        [100, 99, 102, 100, 104, 101, 106, 103, 108, 105, 110]
    )
    result = engine.analyze(candles)

    assert result.trend in {"BULLISH", "BEARISH", "TRANSITION", "RANGE_OR_UNCLEAR", "INSUFFICIENT_DATA"}
    assert 0 <= result.confidence <= 99
    assert isinstance(result.pivots, list)
    assert isinstance(result.structure, list)
