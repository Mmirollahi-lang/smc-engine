from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Literal, Sequence

from .market_structure import Candle, BreakEvent


Direction = Literal["BULLISH", "BEARISH"]


@dataclass(frozen=True)
class DisplacementEvent:
    index: int
    timestamp: str
    direction: Direction
    body_ratio: float
    range_ratio: float
    close_location: float
    atr_ratio: float
    broke_structure: bool
    score: float


@dataclass(frozen=True)
class DisplacementResult:
    valid: bool
    status: Literal["CONFIRMED", "WAIT", "NO_TRADE"]
    direction: Direction | None
    events: list[dict]
    latest: dict | None
    reason: str

    def to_dict(self) -> dict:
        return asdict(self)


class DisplacementEngine:
    """
    Detects strong directional candles.

    A candle qualifies when:
      - body/range is above `min_body_ratio`;
      - close is near the directional end of the range;
      - range is sufficiently large relative to ATR;
      - optionally, the candle coincides with a structure break.

    This engine intentionally does not define an entry. It only validates
    whether price expansion is strong enough to support downstream OB/FVG logic.
    """

    def __init__(
        self,
        atr_period: int = 14,
        min_body_ratio: float = 0.60,
        min_close_location: float = 0.70,
        min_atr_ratio: float = 1.20,
        require_structure_break: bool = False,
    ) -> None:
        if atr_period < 1:
            raise ValueError("atr_period must be >= 1")
        if not 0 < min_body_ratio <= 1:
            raise ValueError("min_body_ratio must be in (0, 1]")
        if not 0.5 <= min_close_location <= 1:
            raise ValueError("min_close_location must be in [0.5, 1]")
        if min_atr_ratio <= 0:
            raise ValueError("min_atr_ratio must be > 0")

        self.atr_period = atr_period
        self.min_body_ratio = min_body_ratio
        self.min_close_location = min_close_location
        self.min_atr_ratio = min_atr_ratio
        self.require_structure_break = require_structure_break

    def analyze(
        self,
        candles: Sequence[Candle],
        structure_breaks: Sequence[BreakEvent] = (),
    ) -> DisplacementResult:
        if len(candles) < self.atr_period + 1:
            return DisplacementResult(
                False, "NO_TRADE", None, [], None,
                "Insufficient candles to calculate ATR."
            )

        break_map = {
            event.index: event
            for event in structure_breaks
            if event.event in {"BOS", "CHoCH"}
        }

        atr_values = self._rolling_atr(candles)
        events: list[DisplacementEvent] = []

        for i, candle in enumerate(candles):
            if i >= len(atr_values) or atr_values[i] is None:
                continue

            rng = candle.high - candle.low
            if rng <= 0:
                continue

            body = abs(candle.close - candle.open)
            body_ratio = body / rng

            bullish = candle.close > candle.open
            if bullish:
                close_location = (candle.close - candle.low) / rng
                direction: Direction = "BULLISH"
            elif candle.close < candle.open:
                close_location = (candle.high - candle.close) / rng
                direction = "BEARISH"
            else:
                continue

            atr = atr_values[i]
            atr_ratio = rng / atr if atr else 0.0
            broke = i in break_map

            if (
                body_ratio >= self.min_body_ratio
                and close_location >= self.min_close_location
                and atr_ratio >= self.min_atr_ratio
                and (not self.require_structure_break or broke)
            ):
                score = self._score(body_ratio, close_location, atr_ratio, broke)
                events.append(
                    DisplacementEvent(
                        i,
                        candle.timestamp,
                        direction,
                        round(body_ratio, 4),
                        round(rng / max(atr, 1e-12), 4),
                        round(close_location, 4),
                        round(atr_ratio, 4),
                        broke,
                        round(score, 2),
                    )
                )

        if not events:
            return DisplacementResult(
                False,
                "WAIT",
                None,
                [],
                None,
                "No candle met the displacement thresholds."
            )

        latest = max(events, key=lambda x: x.index)
        return DisplacementResult(
            True,
            "CONFIRMED",
            latest.direction,
            [asdict(x) for x in events],
            asdict(latest),
            "Directional displacement confirmed."
        )

    def _rolling_atr(self, candles: Sequence[Candle]) -> list[float | None]:
        """Calculate the same simple-moving ATR in O(n) time.

        The previous implementation recomputed each ATR window with ``sum``,
        which made repeated candle-by-candle backtests unnecessarily expensive.
        A rolling sum preserves the exact SMA definition while removing that
        quadratic inner loop.
        """
        n = len(candles)
        if n == 0:
            return []

        true_ranges: list[float] = [0.0] * n
        for i, candle in enumerate(candles):
            if i == 0:
                true_ranges[i] = candle.high - candle.low
            else:
                prev_close = candles[i - 1].close
                true_ranges[i] = max(
                    candle.high - candle.low,
                    abs(candle.high - prev_close),
                    abs(candle.low - prev_close),
                )

        atr: list[float | None] = [None] * n
        period = self.atr_period
        window_sum = 0.0

        for i, tr in enumerate(true_ranges):
            window_sum += tr
            if i >= period:
                window_sum -= true_ranges[i - period]
            if i >= period - 1:
                atr[i] = window_sum / period

        return atr

    @staticmethod
    def _score(
        body_ratio: float,
        close_location: float,
        atr_ratio: float,
        broke_structure: bool,
    ) -> float:
        score = (
            min(body_ratio, 1.0) * 35
            + min(close_location, 1.0) * 25
            + min(atr_ratio / 2.0, 1.0) * 30
            + (10 if broke_structure else 0)
        )
        return min(100.0, score)
