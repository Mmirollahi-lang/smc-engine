from core.market_structure import Candle
from optimize import optimize_and_validate


def c(i, o, h, l, close):
    return Candle(f"t{i}", o, h, l, close)


def test_optimizer_is_deterministic_and_has_holdout():
    candles = [c(i, 100 + i * 0.2, 100.8 + i * 0.2, 99.2 + i * 0.2, 100.3 + i * 0.2) for i in range(80)]
    result = optimize_and_validate(
        candles,
        split_ratio=0.7,
        min_scores=(65.0, 70.0),
        min_rrs=(1.5, 2.0),
    )
    assert result.split_index == 56
    assert len(result.leaderboard) == 4
    assert result.train.min_score in {65.0, 70.0}
    assert result.validation.min_rr == result.train.min_rr


def test_optimizer_rejects_bad_split():
    candles = [c(i, 100, 101, 99, 100) for i in range(20)]
    try:
        optimize_and_validate(candles, split_ratio=0.95)
    except ValueError as exc:
        assert "split_ratio" in str(exc)
    else:
        raise AssertionError("expected ValueError")
