from backtest import Backtester
from core.market_structure import Candle


def c(i, o, h, l, close):
    return Candle(f"t{i}", o, h, l, close)


def test_buy_trade_hits_target():
    candles = [
        c(0, 100, 101, 99, 100),
        c(1, 100, 101, 99.5, 100.5),
        c(2, 100.5, 104, 100, 103.5),
    ]

    def signal(i, history):
        return {"direction": "BUY", "entry": 100, "stop_loss": 98, "take_profit": 103} if i == 1 else None

    result = Backtester().run(candles, signal)
    assert result.total_trades == 1
    assert result.wins == 1
    assert result.net_r == 1.5


def test_same_candle_stop_and_target_is_conservative_loss():
    candles = [
        c(0, 100, 101, 99, 100),
        c(1, 100, 103, 97, 100),
    ]

    def signal(i, history):
        return {"direction": "BUY", "entry": 100, "stop_loss": 98, "take_profit": 102} if i == 0 else None

    result = Backtester().run(candles, signal)
    assert result.total_trades == 1
    assert result.losses == 1
    assert result.net_r == -1.0


def test_signal_without_entry_touch_is_not_filled():
    candles = [
        c(0, 100, 101, 99, 100),
        c(1, 100, 101, 99, 100),
        c(2, 100, 101, 99, 100),
    ]

    def signal(i, history):
        return {"direction": "BUY", "entry": 105, "stop_loss": 98, "take_profit": 110} if i == 0 else None

    result = Backtester().run(candles, signal)
    assert result.total_trades == 0
