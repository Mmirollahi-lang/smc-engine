from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Literal


Bias = Literal["BUY", "SELL"]
Status = Literal["APPROVED", "WAIT", "NO_TRADE"]


@dataclass(frozen=True)
class TradePlan:
    status: Status
    direction: Bias | None
    entry: float | None
    stop_loss: float | None
    tp1: float | None
    tp2: float | None
    risk_reward_tp1: float | None
    risk_reward_tp2: float | None
    reason: str

    def to_dict(self) -> dict:
        return asdict(self)


class EntryEngine:
    """
    Converts a confirmed OB/FVG setup into a deterministic trade plan.

    Entry:
      - Prefer the midpoint of an OB/FVG overlap.
      - Otherwise use the OB midpoint.

    Stop:
      - BUY: below the OB low by `stop_buffer_pct`.
      - SELL: above the OB high by `stop_buffer_pct`.

    Targets:
      - TP1/TP2 are supplied as opposing liquidity/structure levels.
      - A trade is approved only when TP1 meets the minimum R:R.
    """

    def __init__(
        self,
        min_rr: float = 2.0,
        stop_buffer_pct: float = 0.001,
    ) -> None:
        if min_rr <= 0:
            raise ValueError("min_rr must be > 0")
        if stop_buffer_pct < 0:
            raise ValueError("stop_buffer_pct must be >= 0")

        self.min_rr = min_rr
        self.stop_buffer_pct = stop_buffer_pct

    def calculate(
        self,
        bias: Bias,
        order_block: dict | None,
        fvg: dict | None = None,
        tp1_level: float | None = None,
        tp2_level: float | None = None,
    ) -> TradePlan:
        if bias not in ("BUY", "SELL"):
            return TradePlan(
                "NO_TRADE", None, None, None, None, None, None, None,
                "Entry requires a confirmed BUY or SELL bias."
            )

        if not order_block:
            return TradePlan(
                "WAIT", bias, None, None, None, None, None, None,
                "Waiting for a valid order block."
            )

        ob_low = float(order_block["low"])
        ob_high = float(order_block["high"])

        if ob_low >= ob_high:
            return TradePlan(
                "NO_TRADE", bias, None, None, None, None, None, None,
                "Invalid order-block zone."
            )

        entry = self._entry_price(ob_low, ob_high, fvg)
        stop = self._stop_price(bias, ob_low, ob_high)

        if tp1_level is None or tp2_level is None:
            return TradePlan(
                "WAIT", bias, entry, stop, None, None, None, None,
                "Waiting for opposing liquidity/structure targets."
            )

        tp1 = float(tp1_level)
        tp2 = float(tp2_level)

        if not self._targets_are_valid(bias, entry, tp1, tp2):
            return TradePlan(
                "NO_TRADE", bias, entry, stop, tp1, tp2, None, None,
                "Target direction is invalid for the selected bias."
            )

        risk = abs(entry - stop)
        if risk <= 0:
            return TradePlan(
                "NO_TRADE", bias, entry, stop, tp1, tp2, None, None,
                "Entry and stop produce zero risk distance."
            )

        rr1 = abs(tp1 - entry) / risk
        rr2 = abs(tp2 - entry) / risk

        if rr1 < self.min_rr:
            return TradePlan(
                "NO_TRADE",
                bias,
                entry,
                stop,
                tp1,
                tp2,
                round(rr1, 3),
                round(rr2, 3),
                f"TP1 R:R {rr1:.2f} is below minimum {self.min_rr:.2f}.",
            )

        return TradePlan(
            "APPROVED",
            bias,
            entry,
            stop,
            tp1,
            tp2,
            round(rr1, 3),
            round(rr2, 3),
            "Entry, stop, targets and minimum R:R are valid.",
        )

    def _entry_price(
        self,
        ob_low: float,
        ob_high: float,
        fvg: dict | None,
    ) -> float:
        if fvg:
            fvg_low = float(fvg["low"])
            fvg_high = float(fvg["high"])
            overlap_low = max(ob_low, fvg_low)
            overlap_high = min(ob_high, fvg_high)

            if overlap_low <= overlap_high:
                return (overlap_low + overlap_high) / 2.0

        return (ob_low + ob_high) / 2.0

    def _stop_price(
        self,
        bias: Bias,
        ob_low: float,
        ob_high: float,
    ) -> float:
        if bias == "BUY":
            return ob_low * (1.0 - self.stop_buffer_pct)
        return ob_high * (1.0 + self.stop_buffer_pct)

    @staticmethod
    def _targets_are_valid(
        bias: Bias,
        entry: float,
        tp1: float,
        tp2: float,
    ) -> bool:
        if bias == "BUY":
            return tp1 > entry and tp2 > tp1
        return tp1 < entry and tp2 < tp1
