from core.market_structure import Candle, Pivot
from core.liquidity import LiquiditySweepEngine


def candle(i, o, h, l, c):
    return Candle(f"t{i}", o, h, l, c)


def test_equal_high_and_bearish_sweep():
    candles = [
        candle(0, 100, 101, 99, 100),
        candle(1, 100, 105, 99, 104),
        candle(2, 104, 106, 103, 105),
        candle(3, 105, 105.5, 102, 103),
        candle(4, 103, 107, 102, 104),  # sweeps ~105, closes back below
    ]
    pivots = [
        Pivot(1, "t1", "HIGH", 105.0, 0.01),
        Pivot(3, "t3", "HIGH", 105.2, 0.01),
    ]

    engine = LiquiditySweepEngine(
        equal_tolerance_pct=0.003,
        min_pool_spacing=1,
        min_penetration_pct=0.001,
    )
    result = engine.analyze(candles, pivots)

    assert result.status == "CONFIRMED"
    assert len(result.equal_highs) == 1
    assert result.sweeps[0]["direction"] == "BEARISH"


def test_pool_without_sweep_is_wait():
    candles = [
        candle(0, 100, 101, 99, 100),
        candle(1, 100, 105, 99, 104),
        candle(2, 104, 106, 103, 105),
        candle(3, 105, 105.5, 102, 104),
        candle(4, 104, 105.1, 103, 104.8),
    ]
    pivots = [
        Pivot(1, "t1", "HIGH", 105.0, 0.01),
        Pivot(3, "t3", "HIGH", 105.2, 0.01),
    ]

    engine = LiquiditySweepEngine(
        equal_tolerance_pct=0.003,
        min_pool_spacing=1,
        min_penetration_pct=0.001,
    )
    result = engine.analyze(candles, pivots)

    assert result.status == "WAIT"
    assert not result.sweeps
