from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Literal, Optional, Sequence


Bias = Literal["BUY", "SELL", "WAIT", "NO_TRADE"]
PivotType = Literal["HIGH", "LOW"]
StructureLabel = Literal["HH", "HL", "LH", "LL"]


@dataclass(frozen=True)
class Candle:
    timestamp: str
    open: float
    high: float
    low: float
    close: float


@dataclass(frozen=True)
class Pivot:
    index: int
    timestamp: str
    kind: PivotType
    price: float
    strength: float


@dataclass(frozen=True)
class StructurePoint:
    index: int
    timestamp: str
    kind: PivotType
    price: float
    label: StructureLabel


@dataclass(frozen=True)
class BreakEvent:
    index: int
    timestamp: str
    direction: Literal["BULLISH", "BEARISH"]
    event: Literal["BOS", "CHoCH"]
    level: float
    close: float


@dataclass(frozen=True)
class MarketStructureResult:
    bias: Bias
    trend: str
    confidence: float
    pivots: list[dict]
    structure: list[dict]
    bos: list[dict]
    choch: list[dict]
    reason: str

    def to_dict(self) -> dict:
        return {
            "bias": self.bias,
            "trend": self.trend,
            "confidence": self.confidence,
            "pivots": list(self.pivots),
            "structure": list(self.structure),
            "bos": list(self.bos),
            "choch": list(self.choch),
            "reason": self.reason,
        }


class MarketStructureEngine:
    """
    Deterministic market-structure engine.

    Rules:
    - A pivot needs `left/right` candles on both sides.
    - Optional `min_distance_pct` filters weak pivots.
    - HH/HL/LH/LL are classified against the previous pivot of the same kind.
    - A BOS requires a candle CLOSE beyond the latest relevant swing.
    - CHoCH is an early warning only. Bias changes only after opposite structure
      has enough confirmation (LH+LL for bearish, HH+HL for bullish).
    """

    def __init__(
        self,
        left: int = 2,
        right: int = 2,
        min_distance_pct: float = 0.001,
        min_confirmations: int = 2,
    ) -> None:
        if left < 1 or right < 1:
            raise ValueError("left and right must be >= 1")
        if min_distance_pct < 0:
            raise ValueError("min_distance_pct must be >= 0")
        if min_confirmations < 1:
            raise ValueError("min_confirmations must be >= 1")

        self.left = left
        self.right = right
        self.min_distance_pct = min_distance_pct
        self.min_confirmations = min_confirmations

    def detect_pivots(self, candles: Sequence[Candle]) -> list[Pivot]:
        pivots: list[Pivot] = []
        n = len(candles)

        if n < self.left + self.right + 1:
            return pivots

        for i in range(self.left, n - self.right):
            c = candles[i]
            left = candles[i - self.left:i]
            right = candles[i + 1:i + self.right + 1]

            is_high = all(c.high > x.high for x in (*left, *right))
            is_low = all(c.low < x.low for x in (*left, *right))

            if is_high:
                strength = self._pivot_strength(c.high, [x.high for x in (*left, *right)])
                pivots.append(Pivot(i, c.timestamp, "HIGH", c.high, strength))

            if is_low:
                strength = self._pivot_strength(c.low, [x.low for x in (*left, *right)])
                pivots.append(Pivot(i, c.timestamp, "LOW", c.low, strength))

        return self._filter_close_same_type(pivots)

    def classify_structure(self, pivots: Sequence[Pivot]) -> list[StructurePoint]:
        last_high: Optional[float] = None
        last_low: Optional[float] = None
        result: list[StructurePoint] = []

        for p in sorted(pivots, key=lambda x: x.index):
            if p.kind == "HIGH":
                if last_high is not None:
                    label: StructureLabel = "HH" if p.price > last_high else "LH"
                else:
                    # First high has no comparison; omit it from structural labels.
                    last_high = p.price
                    continue
                last_high = p.price
            else:
                if last_low is not None:
                    label = "HL" if p.price > last_low else "LL"
                else:
                    last_low = p.price
                    continue
                last_low = p.price

            result.append(
                StructurePoint(
                    p.index, p.timestamp, p.kind, p.price, label
                )
            )

        return result

    def detect_breaks(
        self,
        candles: Sequence[Candle],
        pivots: Sequence[Pivot],
    ) -> tuple[list[BreakEvent], list[BreakEvent]]:
        """
        Returns (BOS events, CHoCH events).

        A break is based on candle close, never wick-only penetration.
        CHoCH is generated when price closes through the latest protected
        swing against the current structural direction.
        """
        ordered = sorted(pivots, key=lambda p: p.index)
        bos: list[BreakEvent] = []
        choch: list[BreakEvent] = []

        current_bias: Optional[Literal["BULLISH", "BEARISH"]] = None
        last_high: Optional[Pivot] = None
        last_low: Optional[Pivot] = None

        pivot_pos = 0
        for i, candle in enumerate(candles):
            while pivot_pos < len(ordered) and ordered[pivot_pos].index < i:
                pivot = ordered[pivot_pos]
                if pivot.kind == "HIGH":
                    last_high = pivot
                else:
                    last_low = pivot
                pivot_pos += 1

            if last_high and candle.close > last_high.price:
                event = "BOS" if current_bias in (None, "BULLISH") else "CHoCH"
                target = bos if event == "BOS" else choch
                target.append(
                    BreakEvent(
                        i, candle.timestamp, "BULLISH", event,
                        last_high.price, candle.close
                    )
                )
                current_bias = "BULLISH"
                last_high = None

            elif last_low and candle.close < last_low.price:
                event = "BOS" if current_bias in (None, "BEARISH") else "CHoCH"
                target = bos if event == "BOS" else choch
                target.append(
                    BreakEvent(
                        i, candle.timestamp, "BEARISH", event,
                        last_low.price, candle.close
                    )
                )
                current_bias = "BEARISH"
                last_low = None

        return bos, choch

    def analyze(self, candles: Sequence[Candle]) -> MarketStructureResult:
        if len(candles) < self.left + self.right + 5:
            return MarketStructureResult(
                bias="NO_TRADE",
                trend="INSUFFICIENT_DATA",
                confidence=0.0,
                pivots=[],
                structure=[],
                bos=[],
                choch=[],
                reason="Insufficient candles for reliable market-structure analysis.",
            )

        pivots = self.detect_pivots(candles)
        structure = self.classify_structure(pivots)
        bos, choch = self.detect_breaks(candles, pivots)

        labels = [x.label for x in structure[-8:]]
        bullish_score = sum(x in ("HH", "HL") for x in labels)
        bearish_score = sum(x in ("LH", "LL") for x in labels)

        if bullish_score >= self.min_confirmations * 2:
            bias: Bias = "BUY"
            trend = "BULLISH"
            confidence = min(99.0, 70.0 + bullish_score * 4.0)
            reason = "Confirmed HH/HL sequence."
        elif bearish_score >= self.min_confirmations * 2:
            bias = "SELL"
            trend = "BEARISH"
            confidence = min(99.0, 70.0 + bearish_score * 4.0)
            reason = "Confirmed LH/LL sequence."
        elif choch:
            bias = "WAIT"
            trend = "TRANSITION"
            confidence = 50.0
            reason = "CHoCH detected, but opposite structure is not fully confirmed."
        else:
            bias = "NO_TRADE"
            trend = "RANGE_OR_UNCLEAR"
            confidence = 35.0
            reason = "No sufficiently consistent market structure."

        return MarketStructureResult(
            bias=bias,
            trend=trend,
            confidence=round(confidence, 2),
            pivots=[asdict(x) for x in pivots],
            structure=[asdict(x) for x in structure],
            bos=[asdict(x) for x in bos],
            choch=[asdict(x) for x in choch],
            reason=reason,
        )

    def _filter_close_same_type(self, pivots: Sequence[Pivot]) -> list[Pivot]:
        """Filter nearby same-type pivots in O(n) expected time.

        Only the most recent pivot of each type is consulted by the original
        rule, so keeping direct positions avoids repeated reverse scans and
        ``list.index`` calls without changing the rule.
        """
        result: list[Pivot] = []
        last_pos: dict[str, int] = {}

        for pivot in sorted(pivots, key=lambda x: x.index):
            pos = last_pos.get(pivot.kind)
            if pos is None:
                last_pos[pivot.kind] = len(result)
                result.append(pivot)
                continue

            previous = result[pos]
            distance = abs(pivot.price - previous.price) / max(abs(previous.price), 1e-12)

            if distance >= self.min_distance_pct:
                last_pos[pivot.kind] = len(result)
                result.append(pivot)
            elif pivot.strength > previous.strength:
                result[pos] = pivot

        return result

    @staticmethod
    def _pivot_strength(price: float, neighbors: Sequence[float]) -> float:
        if not neighbors:
            return 0.0
        avg_gap = sum(abs(price - x) for x in neighbors) / len(neighbors)
        return round(avg_gap / max(abs(price), 1e-12), 6)
