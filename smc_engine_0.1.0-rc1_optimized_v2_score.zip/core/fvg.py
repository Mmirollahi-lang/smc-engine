from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Literal, Sequence

from .market_structure import Candle


FVGType = Literal["BULLISH", "BEARISH"]


@dataclass(frozen=True)
class FVGZone:
    index: int
    timestamp: str
    type: FVGType
    high: float
    low: float
    size: float
    filled: bool
    fill_index: int | None
    ob_overlap: bool
    score: float


@dataclass(frozen=True)
class FVGResult:
    valid: bool
    status: Literal["CONFIRMED", "WAIT", "NO_TRADE"]
    selected: dict | None
    candidates: list[dict]
    reason: str

    def to_dict(self) -> dict:
        return asdict(self)


class FVGEngine:
    """
    Three-candle Fair Value Gap detector.

    Bullish FVG:
        candle[i-2].high < candle[i].low

    Bearish FVG:
        candle[i-2].low > candle[i].high

    A zone is invalidated only when a later candle fully trades through the
    zone. Partial touches are considered mitigation, not a full fill.
    """

    def __init__(
        self,
        min_gap_pct: float = 0.0005,
        max_lookback: int = 100,
        min_score: float = 50.0,
    ) -> None:
        if min_gap_pct < 0:
            raise ValueError("min_gap_pct must be >= 0")
        if max_lookback < 1:
            raise ValueError("max_lookback must be >= 1")
        if not 0 <= min_score <= 100:
            raise ValueError("min_score must be between 0 and 100")

        self.min_gap_pct = min_gap_pct
        self.max_lookback = max_lookback
        self.min_score = min_score

    def detect(
        self,
        candles: Sequence[Candle],
        order_block: dict | None = None,
    ) -> list[FVGZone]:
        zones: list[FVGZone] = []
        start = max(2, len(candles) - self.max_lookback)

        for i in range(start, len(candles)):
            first = candles[i - 2]
            third = candles[i]

            if first.high < third.low:
                low = first.high
                high = third.low
                if self._large_enough(low, high):
                    zones.append(
                        self._build_zone(
                            candles, i, "BULLISH", low, high, order_block
                        )
                    )

            elif first.low > third.high:
                low = third.high
                high = first.low
                if self._large_enough(low, high):
                    zones.append(
                        self._build_zone(
                            candles, i, "BEARISH", low, high, order_block
                        )
                    )

        return zones

    def analyze(
        self,
        candles: Sequence[Candle],
        order_block: dict | None = None,
    ) -> FVGResult:
        if len(candles) < 3:
            return FVGResult(
                False, "NO_TRADE", None, [],
                "At least three candles are required for FVG detection."
            )

        zones = self.detect(candles, order_block)

        unfilled = [z for z in zones if not z.filled]
        if unfilled:
            ranked = sorted(
                unfilled,
                key=lambda z: (z.score, z.index),
                reverse=True,
            )
            selected = ranked[0]
            return FVGResult(
                True,
                "CONFIRMED",
                asdict(selected),
                [asdict(z) for z in ranked],
                "Unfilled FVG confirmed."
            )

        if zones:
            return FVGResult(
                False,
                "WAIT",
                None,
                [asdict(z) for z in zones],
                "FVGs were detected, but all are filled."
            )

        return FVGResult(
            False,
            "NO_TRADE",
            None,
            [],
            "No valid FVG was detected."
        )

    def _build_zone(
        self,
        candles: Sequence[Candle],
        index: int,
        fvg_type: FVGType,
        low: float,
        high: float,
        order_block: dict | None,
    ) -> FVGZone:
        fill_index = None

        for j in range(index + 1, len(candles)):
            candle = candles[j]

            # Full fill: price reaches the opposite edge of the gap.
            if fvg_type == "BULLISH" and candle.low <= low:
                fill_index = j
                break
            if fvg_type == "BEARISH" and candle.high >= high:
                fill_index = j
                break

        filled = fill_index is not None
        overlap = False

        if order_block:
            ob_low = float(order_block["low"])
            ob_high = float(order_block["high"])
            overlap = max(low, ob_low) <= min(high, ob_high)

        gap_size = high - low
        score = self._score(
            gap_size / max(abs(low), 1e-12),
            not filled,
            overlap,
        )

        return FVGZone(
            index=index,
            timestamp=candles[index].timestamp,
            type=fvg_type,
            high=high,
            low=low,
            size=gap_size,
            filled=filled,
            fill_index=fill_index,
            ob_overlap=overlap,
            score=round(score, 2),
        )

    def _large_enough(self, low: float, high: float) -> bool:
        return (high - low) / max(abs(low), 1e-12) >= self.min_gap_pct

    @staticmethod
    def _score(
        gap_pct: float,
        unfilled: bool,
        overlap: bool,
    ) -> float:
        score = min(gap_pct / 0.01, 1.0) * 45.0
        score += 35.0 if unfilled else 0.0
        score += 20.0 if overlap else 0.0
        return min(100.0, score)
