from core.market_structure import Candle
from core.displacement import DisplacementEngine


def c(i, o, h, l, close):
    return Candle(f"t{i}", o, h, l, close)


def test_strong_bullish_displacement():
    candles = []
    for i in range(15):
        price = 100 + i * 0.1
        candles.append(c(i, price, price + 0.2, price - 0.2, price + 0.05))

    # Large expansion with a strong bullish close.
    candles.append(c(15, 101.5, 104.5, 101.4, 104.4))

    result = DisplacementEngine(
        atr_period=5,
        min_body_ratio=0.6,
        min_close_location=0.7,
        min_atr_ratio=1.2,
    ).analyze(candles)

    assert result.valid
    assert result.status == "CONFIRMED"
    assert result.direction == "BULLISH"
    assert result.latest is not None
    assert result.latest["score"] > 0


def test_no_displacement_on_small_candles():
    candles = [
        c(i, 100 + i * 0.01, 100 + i * 0.03, 100 + i * 0.0, 100 + i * 0.02)
        for i in range(20)
    ]

    result = DisplacementEngine(
        atr_period=5,
        min_atr_ratio=3.0,
    ).analyze(candles)

    assert not result.valid
    assert result.status == "WAIT"
