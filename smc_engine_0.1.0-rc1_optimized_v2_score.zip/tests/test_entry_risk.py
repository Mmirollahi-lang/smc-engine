from core.entry_engine import EntryEngine
from core.risk_manager import RiskManager


def test_buy_entry_approved_with_good_rr():
    plan = EntryEngine(min_rr=2.0).calculate(
        bias="BUY",
        order_block={"low": 100.0, "high": 102.0},
        fvg={"low": 100.5, "high": 101.5},
        tp1_level=108.0,
        tp2_level=114.0,
    )

    assert plan.status == "APPROVED"
    assert plan.direction == "BUY"
    assert plan.risk_reward_tp1 >= 2.0
    assert plan.tp2 > plan.tp1


def test_bad_rr_is_rejected():
    plan = EntryEngine(min_rr=2.0).calculate(
        bias="BUY",
        order_block={"low": 100.0, "high": 102.0},
        tp1_level=103.0,
        tp2_level=104.0,
    )

    assert plan.status == "NO_TRADE"


def test_risk_manager_sizes_position():
    result = RiskManager(risk_pct=1.0).calculate(
        balance=10000.0,
        entry=100.0,
        stop_loss=98.0,
    )

    assert result.approved
    assert result.risk_amount == 100.0
    assert result.position_size == 50.0
    assert result.notional == 5000.0


def test_invalid_risk_inputs_are_rejected():
    result = RiskManager().calculate(
        balance=0,
        entry=100,
        stop_loss=98,
    )
    assert not result.approved
