from core.market_structure import Candle, Pivot, MarketStructureEngine
from core.liquidity import LiquiditySweepEngine
from core.displacement import DisplacementEngine, DisplacementEvent
from core.order_block import OrderBlockEngine
from core.fvg import FVGEngine
from core.entry_engine import EntryEngine
from core.risk_manager import RiskManager


def c(i, o, h, l, close):
    return Candle(f"scenario-{i}", o, h, l, close)


def bullish_sweep_scenario():
    # Equal lows around 100, then a wick below them and a reclaim.
    candles = [
        c(0, 101, 102, 100.0, 101.2),
        c(1, 101.2, 103, 100.2, 102.5),
        c(2, 102.5, 103, 100.0, 102.0),
        c(3, 102.0, 103.5, 100.8, 103.2),
        c(4, 103.2, 104.0, 99.5, 103.0),  # sweep below 100 and reclaim
    ]
    pivots = [
        Pivot(0, "scenario-0", "LOW", 100.0, 0.02),
        Pivot(2, "scenario-2", "LOW", 100.0, 0.02),
    ]
    return candles, pivots


def bearish_sweep_scenario():
    candles = [
        c(0, 99, 100.0, 98, 99.0),
        c(1, 99, 100.0, 97.5, 98.0),
        c(2, 98, 100.0, 97.0, 98.5),
        c(3, 98.5, 101.0, 97.8, 99.5),
        c(4, 99.5, 100.7, 98.5, 99.0),  # sweeps ~100 and closes back below
    ]
    pivots = [
        Pivot(0, "scenario-0", "HIGH", 100.0, 0.02),
        Pivot(2, "scenario-2", "HIGH", 100.0, 0.02),
    ]
    return candles, pivots


def test_bullish_and_bearish_liquidity_sweeps_are_detected():
    engine = LiquiditySweepEngine(
        equal_tolerance_pct=0.001,
        min_pool_spacing=1,
        min_penetration_pct=0.001,
    )

    candles, pivots = bullish_sweep_scenario()
    result = engine.analyze(candles, pivots)
    assert result.status == "CONFIRMED"
    assert result.sweeps[0]["direction"] == "BULLISH"

    candles, pivots = bearish_sweep_scenario()
    result = engine.analyze(candles, pivots)
    assert result.status == "CONFIRMED"
    assert result.sweeps[0]["direction"] == "BEARISH"


def test_displacement_order_block_fvg_and_entry_chain():
    # Bearish candle creates the OB, then a large bullish displacement leaves
    # a bullish FVG. The explicit displacement object represents the output of
    # the upstream detector, while the FVG and OB are detected from candles.
    candles = [
        c(0, 100.0, 100.8, 99.5, 100.4),
        c(1, 100.4, 101.0, 99.8, 100.0),   # bearish OB candidate
        c(2, 100.0, 104.5, 100.8, 104.2), # bullish displacement
        c(3, 104.2, 106.0, 104.0, 105.8),
        c(4, 105.8, 106.8, 105.5, 106.5),
    ]

    displacement = DisplacementEngine(atr_period=2, min_atr_ratio=1.0).analyze(candles)
    assert displacement.valid
    assert displacement.direction == "BULLISH"

    events = [DisplacementEvent(**x) for x in displacement.events]
    ob = OrderBlockEngine(min_score=0).analyze(candles, events)
    assert ob.valid
    assert ob.selected["type"] == "BULLISH"
    assert ob.selected["index"] == 1

    fvg = FVGEngine(min_gap_pct=0.005).analyze(candles, ob.selected)
    assert fvg.valid
    assert fvg.selected["type"] == "BULLISH"
    assert fvg.selected["ob_overlap"] is True

    plan = EntryEngine(min_rr=1.5).calculate(
        "BUY",
        ob.selected,
        fvg.selected,
        tp1_level=110.0,
        tp2_level=115.0,
    )
    assert plan.status == "APPROVED"
    assert plan.risk_reward_tp1 >= 1.5

    risk = RiskManager(risk_pct=1.0).calculate(
        balance=10_000,
        entry=plan.entry,
        stop_loss=plan.stop_loss,
    )
    assert risk.approved
    assert risk.risk_amount > 0


def test_market_structure_control_scenario_has_enough_data():
    # Deliberately alternating swings produce identifiable pivots and ensure
    # the structure detector is exercised on a non-monotonic series.
    closes = [100, 102, 99, 103, 100, 105, 101, 106, 102, 107, 103, 108]
    candles = []
    for i, close in enumerate(closes):
        candles.append(c(i, close, close + 0.5, close - 0.5, close))

    result = MarketStructureEngine(left=1, right=1, min_distance_pct=0.001).analyze(candles)
    assert result.pivots
    assert result.structure
    assert result.bias in {"BUY", "SELL", "WAIT", "NO_TRADE"}
