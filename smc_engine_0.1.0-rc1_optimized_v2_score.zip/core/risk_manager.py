from __future__ import annotations

from dataclasses import dataclass, asdict


@dataclass(frozen=True)
class RiskResult:
    approved: bool
    risk_amount: float
    stop_distance: float
    position_size: float
    notional: float
    risk_pct: float
    reason: str

    def to_dict(self) -> dict:
        return asdict(self)


class RiskManager:
    """Position sizing based on fixed account-risk percentage."""

    def __init__(
        self,
        risk_pct: float = 1.0,
        max_notional_pct: float | None = None,
    ) -> None:
        if risk_pct <= 0:
            raise ValueError("risk_pct must be > 0")
        if max_notional_pct is not None and max_notional_pct <= 0:
            raise ValueError("max_notional_pct must be > 0")

        self.risk_pct = risk_pct
        self.max_notional_pct = max_notional_pct

    def calculate(
        self,
        balance: float,
        entry: float,
        stop_loss: float,
    ) -> RiskResult:
        if balance <= 0:
            return self._reject("Balance must be positive.")
        if entry <= 0 or stop_loss <= 0:
            return self._reject("Entry and stop must be positive.")

        distance = abs(entry - stop_loss)
        if distance <= 0:
            return self._reject("Entry and stop cannot be equal.")

        risk_amount = balance * (self.risk_pct / 100.0)
        position_size = risk_amount / distance
        notional = position_size * entry

        if self.max_notional_pct is not None:
            max_notional = balance * (self.max_notional_pct / 100.0)
            if notional > max_notional:
                position_size = max_notional / entry
                notional = max_notional
                risk_amount = position_size * distance

        return RiskResult(
            approved=True,
            risk_amount=round(risk_amount, 8),
            stop_distance=round(distance, 8),
            position_size=round(position_size, 8),
            notional=round(notional, 8),
            risk_pct=round((risk_amount / balance) * 100.0, 6),
            reason="Position size calculated from fixed account risk.",
        )

    @staticmethod
    def _reject(reason: str) -> RiskResult:
        return RiskResult(
            approved=False,
            risk_amount=0.0,
            stop_distance=0.0,
            position_size=0.0,
            notional=0.0,
            risk_pct=0.0,
            reason=reason,
        )
