from main import SMCEngine
from core.market_structure import Candle


def candle(i, close):
    return Candle(
        timestamp=f"t{i}",
        open=close,
        high=close + 0.4,
        low=close - 0.4,
        close=close,
    )


def test_pipeline_handles_insufficient_structure_without_crashing():
    candles = [candle(i, 100 + i * 0.1) for i in range(5)]
    result = SMCEngine().analyze(candles)

    assert result["status"] in {"NO_TRADE", "WAIT"}
    assert "market_structure" in result


def test_pipeline_accepts_explicit_targets_and_balance():
    # This verifies the public API contract. The data may legitimately stop
    # before a trade is approved; the pipeline must still return a structured
    # result without inventing downstream information.
    candles = [
        Candle(f"t{i}", 100 + i * 0.2, 101 + i * 0.2, 99 + i * 0.2, 100.2 + i * 0.2)
        for i in range(30)
    ]
    result = SMCEngine().analyze(
        candles,
        balance=10_000,
        tp1_level=110,
        tp2_level=115,
    )

    assert "status" in result
    assert "market_structure" in result
