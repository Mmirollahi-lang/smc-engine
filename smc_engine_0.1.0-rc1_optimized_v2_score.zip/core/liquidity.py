from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Literal, Sequence

from .market_structure import Candle, Pivot


LiquidityType = Literal["EQUAL_HIGH", "EQUAL_LOW"]
SweepDirection = Literal["BULLISH", "BEARISH"]


@dataclass(frozen=True)
class LiquidityPool:
    kind: LiquidityType
    first_index: int
    second_index: int
    first_price: float
    second_price: float
    level: float
    tolerance_pct: float


@dataclass(frozen=True)
class LiquiditySweep:
    index: int
    timestamp: str
    direction: SweepDirection
    pool_kind: LiquidityType
    level: float
    wick_price: float
    close: float
    penetration_pct: float


@dataclass(frozen=True)
class LiquidityResult:
    equal_highs: list[dict]
    equal_lows: list[dict]
    sweeps: list[dict]
    status: Literal["CONFIRMED", "WAIT", "NO_TRADE"]
    reason: str

    def to_dict(self) -> dict:
        return asdict(self)


class LiquiditySweepEngine:
    """
    Detects equal-high/equal-low liquidity pools and wick-and-reclaim sweeps.

    Equal highs/lows use percentage tolerance rather than an absolute tick size,
    making the rule usable across instruments with different price scales.

    A sweep is confirmed only when:
      - a candle trades beyond the liquidity level with its wick, and
      - its close returns to the liquidity level or back through it.

    This module does not decide whether a CHoCH/BOS followed the sweep.
    """

    def __init__(
        self,
        equal_tolerance_pct: float = 0.0015,
        min_pool_spacing: int = 2,
        max_pool_spacing: int = 80,
        min_penetration_pct: float = 0.0002,
    ) -> None:
        if equal_tolerance_pct < 0:
            raise ValueError("equal_tolerance_pct must be >= 0")
        if min_pool_spacing < 1:
            raise ValueError("min_pool_spacing must be >= 1")
        if max_pool_spacing < min_pool_spacing:
            raise ValueError("max_pool_spacing must be >= min_pool_spacing")
        if min_penetration_pct < 0:
            raise ValueError("min_penetration_pct must be >= 0")

        self.equal_tolerance_pct = equal_tolerance_pct
        self.min_pool_spacing = min_pool_spacing
        self.max_pool_spacing = max_pool_spacing
        self.min_penetration_pct = min_penetration_pct

    def find_equal_pools(self, pivots: Sequence[Pivot]) -> tuple[list[LiquidityPool], list[LiquidityPool]]:
        highs = [p for p in pivots if p.kind == "HIGH"]
        lows = [p for p in pivots if p.kind == "LOW"]

        return (
            self._pair_equal_pivots(highs, "EQUAL_HIGH"),
            self._pair_equal_pivots(lows, "EQUAL_LOW"),
        )

    def detect_sweeps(
        self,
        candles: Sequence[Candle],
        pools: Sequence[LiquidityPool],
    ) -> list[LiquiditySweep]:
        sweeps: list[LiquiditySweep] = []

        for pool in pools:
            start = pool.second_index + 1
            end = min(len(candles), pool.second_index + self.max_pool_spacing + 1)

            for i in range(start, end):
                candle = candles[i]

                if pool.kind == "EQUAL_HIGH":
                    penetration = (candle.high - pool.level) / pool.level
                    reclaimed = candle.close <= pool.level

                    if penetration >= self.min_penetration_pct and reclaimed:
                        sweeps.append(
                            LiquiditySweep(
                                i,
                                candle.timestamp,
                                "BEARISH",
                                pool.kind,
                                pool.level,
                                candle.high,
                                candle.close,
                                round(penetration, 6),
                            )
                        )
                        break

                else:
                    penetration = (pool.level - candle.low) / pool.level
                    reclaimed = candle.close >= pool.level

                    if penetration >= self.min_penetration_pct and reclaimed:
                        sweeps.append(
                            LiquiditySweep(
                                i,
                                candle.timestamp,
                                "BULLISH",
                                pool.kind,
                                pool.level,
                                candle.low,
                                candle.close,
                                round(penetration, 6),
                            )
                        )
                        break

        return sorted(sweeps, key=lambda x: x.index)

    def analyze(
        self,
        candles: Sequence[Candle],
        pivots: Sequence[Pivot],
    ) -> LiquidityResult:
        equal_highs, equal_lows = self.find_equal_pools(pivots)
        pools = [*equal_highs, *equal_lows]
        sweeps = self.detect_sweeps(candles, pools)

        if sweeps:
            return LiquidityResult(
                equal_highs=[asdict(x) for x in equal_highs],
                equal_lows=[asdict(x) for x in equal_lows],
                sweeps=[asdict(x) for x in sweeps],
                status="CONFIRMED",
                reason="Liquidity sweep confirmed by wick penetration and reclaim close.",
            )

        if pools:
            return LiquidityResult(
                equal_highs=[asdict(x) for x in equal_highs],
                equal_lows=[asdict(x) for x in equal_lows],
                sweeps=[],
                status="WAIT",
                reason="Liquidity pool exists, but no confirmed sweep was detected.",
            )

        return LiquidityResult(
            equal_highs=[],
            equal_lows=[],
            sweeps=[],
            status="NO_TRADE",
            reason="No equal-high or equal-low liquidity pool was detected.",
        )

    def _pair_equal_pivots(
        self,
        pivots: Sequence[Pivot],
        kind: LiquidityType,
    ) -> list[LiquidityPool]:
        result: list[LiquidityPool] = []
        ordered = sorted(pivots, key=lambda x: x.index)

        for i, first in enumerate(ordered):
            for second in ordered[i + 1:]:
                spacing = second.index - first.index
                if spacing < self.min_pool_spacing:
                    continue
                if spacing > self.max_pool_spacing:
                    break

                distance = abs(second.price - first.price) / max(abs(first.price), 1e-12)
                if distance <= self.equal_tolerance_pct:
                    result.append(
                        LiquidityPool(
                            kind=kind,
                            first_index=first.index,
                            second_index=second.index,
                            first_price=first.price,
                            second_price=second.price,
                            level=(first.price + second.price) / 2.0,
                            tolerance_pct=distance,
                        )
                    )
                    break

        return result
