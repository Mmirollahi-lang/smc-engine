from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Literal, Sequence

from .market_structure import Candle, BreakEvent
from .displacement import DisplacementEvent


OBType = Literal["BULLISH", "BEARISH"]


@dataclass(frozen=True)
class OrderBlock:
    index: int
    timestamp: str
    type: OBType
    high: float
    low: float
    displacement_index: int
    break_event: str | None
    fresh: bool
    mitigated: bool
    fvg_overlap: bool
    score: float


@dataclass(frozen=True)
class OrderBlockResult:
    valid: bool
    status: Literal["CONFIRMED", "WAIT", "NO_TRADE"]
    selected: dict | None
    candidates: list[dict]
    reason: str

    def to_dict(self) -> dict:
        return asdict(self)


class OrderBlockEngine:
    """
    Finds the last opposite candle before a confirmed displacement.

    Bullish OB:
      last bearish candle before bullish displacement.

    Bearish OB:
      last bullish candle before bearish displacement.

    The OB becomes invalid if price later closes through the far side of its zone.
    A wick into the zone alone is considered mitigation, not invalidation.
    """

    def __init__(
        self,
        lookback: int = 8,
        min_score: float = 60.0,
        require_break: bool = False,
    ) -> None:
        if lookback < 1:
            raise ValueError("lookback must be >= 1")
        if not 0 <= min_score <= 100:
            raise ValueError("min_score must be between 0 and 100")

        self.lookback = lookback
        self.min_score = min_score
        self.require_break = require_break

    def analyze(
        self,
        candles: Sequence[Candle],
        displacement_events: Sequence[DisplacementEvent] = (),
        structure_breaks: Sequence[BreakEvent] = (),
        fvg_zones: Sequence[tuple[float, float]] = (),
    ) -> OrderBlockResult:
        if not candles or not displacement_events:
            return OrderBlockResult(
                False, "NO_TRADE", None, [],
                "No displacement event available for order-block detection."
            )

        break_map = {event.index: event for event in structure_breaks}
        n = len(candles)
        suffix_min_low = [float("inf")] * n
        suffix_max_high = [float("-inf")] * n
        suffix_min_close = [float("inf")] * n
        suffix_max_close = [float("-inf")] * n
        for i in range(n - 1, -1, -1):
            candle = candles[i]
            if i == n - 1:
                suffix_min_low[i] = candle.low
                suffix_max_high[i] = candle.high
                suffix_min_close[i] = candle.close
                suffix_max_close[i] = candle.close
            else:
                suffix_min_low[i] = min(candle.low, suffix_min_low[i + 1])
                suffix_max_high[i] = max(candle.high, suffix_max_high[i + 1])
                suffix_min_close[i] = min(candle.close, suffix_min_close[i + 1])
                suffix_max_close[i] = max(candle.close, suffix_max_close[i + 1])
        candidates: list[OrderBlock] = []

        for disp in displacement_events:
            start = max(0, disp.index - self.lookback)
            ob_index = self._find_last_opposite_candle(
                candles, start, disp.index, disp.direction
            )
            if ob_index is None:
                continue

            candle = candles[ob_index]
            ob_type: OBType = "BULLISH" if disp.direction == "BULLISH" else "BEARISH"
            zone_high = candle.high
            zone_low = candle.low

            break_event = break_map.get(disp.index)
            if self.require_break and break_event is None:
                continue

            future_start = disp.index + 1
            if future_start < n:
                if ob_type == "BULLISH":
                    mitigated = suffix_min_low[future_start] <= zone_high
                    invalidated = suffix_min_close[future_start] < zone_low
                else:
                    mitigated = suffix_max_high[future_start] >= zone_low
                    invalidated = suffix_max_close[future_start] > zone_high
            else:
                mitigated = False
                invalidated = False

            if invalidated:
                continue

            overlap = any(
                self._zones_overlap(zone_low, zone_high, low, high)
                for low, high in fvg_zones
            )

            score = self._score(
                disp.score,
                fresh=not mitigated,
                fvg_overlap=overlap,
                structure_break=break_event is not None,
            )

            candidates.append(
                OrderBlock(
                    index=ob_index,
                    timestamp=candle.timestamp,
                    type=ob_type,
                    high=zone_high,
                    low=zone_low,
                    displacement_index=disp.index,
                    break_event=break_event.event if break_event else None,
                    fresh=not mitigated,
                    mitigated=mitigated,
                    fvg_overlap=overlap,
                    score=round(score, 2),
                )
            )

        candidates = sorted(
            candidates,
            key=lambda x: (x.score, x.index),
            reverse=True,
        )

        valid = [x for x in candidates if x.score >= self.min_score and not x.mitigated]

        if valid:
            selected = valid[0]
            return OrderBlockResult(
                True,
                "CONFIRMED",
                asdict(selected),
                [asdict(x) for x in candidates],
                "Fresh order block confirmed after displacement."
            )

        if candidates:
            return OrderBlockResult(
                False,
                "WAIT",
                None,
                [asdict(x) for x in candidates],
                "Order-block candidates exist, but none passed freshness/score filters."
            )

        return OrderBlockResult(
            False,
            "NO_TRADE",
            None,
            [],
            "No valid opposite candle was found before displacement."
        )

    @staticmethod
    def _find_last_opposite_candle(
        candles: Sequence[Candle],
        start: int,
        end: int,
        direction: OBType,
    ) -> int | None:
        for i in range(end - 1, start - 1, -1):
            candle = candles[i]
            if direction == "BULLISH" and candle.close < candle.open:
                return i
            if direction == "BEARISH" and candle.close > candle.open:
                return i
        return None

    @staticmethod
    def _zones_overlap(
        low_a: float,
        high_a: float,
        low_b: float,
        high_b: float,
    ) -> bool:
        return max(low_a, low_b) <= min(high_a, high_b)

    @staticmethod
    def _score(
        displacement_score: float,
        fresh: bool,
        fvg_overlap: bool,
        structure_break: bool,
    ) -> float:
        score = min(displacement_score, 100.0) * 0.55
        score += 20.0 if fresh else 0.0
        score += 15.0 if fvg_overlap else 0.0
        score += 10.0 if structure_break else 0.0
        return min(100.0, score)
