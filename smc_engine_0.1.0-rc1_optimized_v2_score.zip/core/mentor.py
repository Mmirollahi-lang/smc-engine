from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class MentorExplanation:
    summary: str
    bullets: list[str]
    action: str

    def to_dict(self) -> dict:
        return {
            "summary": self.summary,
            "bullets": self.bullets,
            "action": self.action,
        }


class MentorEngine:
    """Turns machine output into a concise, human-readable explanation."""

    def explain(self, setup: dict, score: dict) -> MentorExplanation:
        direction = setup.get("bias", "WAIT")
        total = float(score.get("total", 0.0))
        score_decision = score.get("decision", "REJECT")
        entry_status = setup.get("entry_status", "NO_TRADE")
        final_decision = setup.get("final_decision")
        decision = final_decision or ("APPROVE" if entry_status == "APPROVED" and score_decision == "APPROVE" else "REJECT")

        bullets = [
            f"Bias: {direction}.",
            f"Overall score: {total:.1f}/100 ({score.get('grade', 'F')}).",
        ]

        if setup.get("liquidity_sweep"):
            bullets.append("Liquidity was swept and reclaimed.")
        else:
            bullets.append("Liquidity sweep is not confirmed.")

        if setup.get("choch_confirmed"):
            bullets.append("CHoCH confirmation is present.")
        elif setup.get("bos_confirmed"):
            bullets.append("BOS confirmation is present.")
        else:
            bullets.append("No decisive structure-break confirmation is present.")

        if setup.get("displacement"):
            bullets.append("Displacement confirms strong directional intent.")
        else:
            bullets.append("Displacement is insufficient.")

        if setup.get("order_block"):
            bullets.append("A valid order block is available.")
        else:
            bullets.append("A valid order block is missing.")

        if setup.get("fvg"):
            bullets.append("An FVG is available for confluence.")
        else:
            bullets.append("FVG confluence is missing.")

        rr = float(setup.get("rr_tp1", 0.0) or 0.0)
        bullets.append(f"TP1 R:R is {rr:.2f}.")

        if entry_status == "APPROVED" and score_decision == "APPROVE":
            action = "Setup passes scoring and entry/R:R checks; continue to execution/risk checks."
            summary = f"{direction} setup is approved for execution."
        elif entry_status == "WAIT":
            action = "WAIT until entry/target conditions are confirmed."
            summary = f"{direction} setup is waiting for valid entry conditions."
        elif entry_status == "NO_TRADE":
            reason = setup.get("entry_reason") or "Entry/R:R conditions are not satisfied."
            action = f"NO_TRADE: {reason}"
            summary = f"{direction} setup is rejected by the entry/risk gate."
        else:
            action = "WAIT / REJECT until the missing conditions improve."
            summary = f"{direction} setup is not approved yet."

        return MentorExplanation(summary, bullets, action)
