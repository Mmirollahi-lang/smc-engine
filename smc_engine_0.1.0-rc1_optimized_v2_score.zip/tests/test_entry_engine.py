from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Callable, Sequence

from core.market_structure import Candle


@dataclass(frozen=True)
class BacktestTrade:
    entry_index: int
    exit_index: int
    direction: str
    entry: float
    stop_loss: float
    take_profit: float
    pnl_r: float
    outcome: str


@dataclass(frozen=True)
class BacktestResult:
    trades: list[dict]
    total_trades: int
    wins: int
    losses: int
    breakeven: int
    win_rate_pct: float
    net_r: float
    profit_factor: float | None
    max_drawdown_r: float

    def to_dict(self) -> dict:
        return asdict(self)


class Backtester:
    """Deterministic candle-by-candle limit-entry execution simulator.

    Flow:
      1. Signal creates a pending limit order.
      2. Future candles are checked until entry is touched.
      3. Once entry is filled, SL/TP are evaluated.
      4. The same setup is not re-entered repeatedly.

    No future candles are passed to signal_fn.
    """

    def run(
        self,
        candles: Sequence[Candle],
        signal_fn: Callable[[int, Sequence[Candle]], dict | None],
    ) -> BacktestResult:
        trades: list[BacktestTrade] = []
        seen_setups: set[tuple] = set()
        i = 0

        while i < len(candles):
            signal = signal_fn(i, candles[: i + 1])

            if not signal:
                i += 1
                continue

            direction = signal.get("direction")
            try:
                entry = float(signal.get("entry", 0))
                stop = float(signal.get("stop_loss", 0))
                target = float(signal.get("take_profit", 0))
            except (TypeError, ValueError):
                i += 1
                continue

            if (
                direction not in {"BUY", "SELL"}
                or entry <= 0
                or stop <= 0
                or target <= 0
            ):
                i += 1
                continue

            if direction == "BUY" and not (stop < entry < target):
                i += 1
                continue

            if direction == "SELL" and not (target < entry < stop):
                i += 1
                continue

            # A setup is identified by direction + entry + stop.
            # TP may legitimately change as new liquidity levels appear,
            # but that must not create a brand-new trade from the same setup.
            setup_key = (
                direction,
                round(entry, 8),
                round(stop, 8),
            )

            if setup_key in seen_setups:
                i += 1
                continue

            seen_setups.add(setup_key)

            risk = abs(entry - stop)
            if risk <= 0:
                i += 1
                continue

            fill_index = None
            exit_index = None
            outcome = "TIMEOUT"
            pnl_r = 0.0

            # ---------------------------------------------------------
            # Phase 1: pending limit order.
            # ---------------------------------------------------------
            for j in range(i + 1, len(candles)):
                c = candles[j]

                if direction == "BUY":
                    entry_touched = c.low <= entry <= c.high
                else:
                    entry_touched = c.low <= entry <= c.high

                if not entry_touched:
                    continue

                fill_index = j

                # Entry candle can also hit SL/TP.
                if direction == "BUY":
                    hit_stop = c.low <= stop
                    hit_target = c.high >= target
                else:
                    hit_stop = c.high >= stop
                    hit_target = c.low <= target

                # Conservative intrabar assumption:
                # if both are touched, SL wins.
                if hit_stop:
                    exit_index = j
                    outcome = "LOSS"
                    pnl_r = -1.0
                    break

                if hit_target:
                    exit_index = j
                    outcome = "WIN"
                    pnl_r = abs(target - entry) / risk
                    break

                # -----------------------------------------------------
                # Phase 2: position is active after entry fill.
                # -----------------------------------------------------
                for k in range(j + 1, len(candles)):
                    future = candles[k]

                    if direction == "BUY":
                        hit_stop = future.low <= stop
                        hit_target = future.high >= target
                    else:
                        hit_stop = future.high >= stop
                        hit_target = future.low <= target

                    if hit_stop:
                        exit_index = k
                        outcome = "LOSS"
                        pnl_r = -1.0
                        break

                    if hit_target:
                        exit_index = k
                        outcome = "WIN"
                        pnl_r = abs(target - entry) / risk
                        break

                break

            # Entry was never filled.
            if fill_index is None:
                i += 1
                continue

            # Entry filled but neither SL nor TP was reached.
            if exit_index is None:
                i += 1
                continue

            trades.append(
                BacktestTrade(
                    entry_index=fill_index,
                    exit_index=exit_index,
                    direction=direction,
                    entry=entry,
                    stop_loss=stop,
                    take_profit=target,
                    pnl_r=round(pnl_r, 6),
                    outcome=outcome,
                )
            )

            # Resume scanning only after the position has closed.
            i = exit_index + 1

        wins = sum(t.outcome == "WIN" for t in trades)
        losses = sum(t.outcome == "LOSS" for t in trades)
        breakeven = sum(t.outcome == "BREAKEVEN" for t in trades)

        total = len(trades)
        win_rate = (wins / total * 100.0) if total else 0.0

        gross_profit = sum(
            t.pnl_r for t in trades if t.pnl_r > 0
        )
        gross_loss = -sum(
            t.pnl_r for t in trades if t.pnl_r < 0
        )

        profit_factor = (
            gross_profit / gross_loss
            if gross_loss
            else (None if not gross_profit else float("inf"))
        )

        equity = 0.0
        peak = 0.0
        max_dd = 0.0

        for trade in trades:
            equity += trade.pnl_r
            peak = max(peak, equity)
            max_dd = max(max_dd, peak - equity)

        return BacktestResult(
            trades=[asdict(t) for t in trades],
            total_trades=total,
            wins=wins,
            losses=losses,
            breakeven=breakeven,
            win_rate_pct=round(win_rate, 2),
            net_r=round(
                sum(t.pnl_r for t in trades),
                4,
            ),
            profit_factor=(
                None
                if profit_factor is None
                else round(profit_factor, 4)
            ),
            max_drawdown_r=round(max_dd, 4),
        )