from core.scoring import ScoringEngine
from core.mentor import MentorEngine


def test_strong_setup_scores_high():
    setup = {
        "structure_confidence": 95,
        "liquidity_sweep": True,
        "displacement_score": 95,
        "order_block_score": 90,
        "fvg_score": 90,
        "rr_tp1": 3.0,
    }
    result = ScoringEngine(min_score=70).score(setup)

    assert result.total >= 70
    assert result.decision == "APPROVE"
    assert result.grade in {"A", "B"}


def test_weak_setup_is_rejected():
    setup = {
        "structure_confidence": 30,
        "liquidity_sweep": False,
        "displacement_score": 20,
        "order_block_score": 0,
        "fvg_score": 0,
        "rr_tp1": 0.5,
    }
    result = ScoringEngine(min_score=70).score(setup)

    assert result.decision == "REJECT"


def test_mentor_explains_decision():
    setup = {
        "bias": "BUY",
        "liquidity_sweep": True,
        "choch_confirmed": True,
        "displacement": True,
        "order_block": True,
        "fvg": True,
        "rr_tp1": 3.2,
    }
    score = {"total": 91, "grade": "A", "decision": "APPROVE"}

    result = MentorEngine().explain(setup, score)

    assert result.action
    assert "91.0/100" in result.bullets[1]
    assert any("CHoCH" in x for x in result.bullets)


def test_mentor_never_approves_when_entry_gate_rejects():
    setup = {
        "bias": "BUY",
        "liquidity_sweep": True,
        "choch_confirmed": True,
        "displacement": True,
        "order_block": True,
        "fvg": True,
        "rr_tp1": 0.0,
        "entry_status": "NO_TRADE",
        "entry_reason": "TP1 R:R 0.00 is below minimum 2.00.",
    }
    score = {"total": 70.8, "grade": "C", "decision": "APPROVE"}

    result = MentorEngine().explain(setup, score)

    assert "approved" not in result.summary.lower()
    assert "NO_TRADE" in result.action
