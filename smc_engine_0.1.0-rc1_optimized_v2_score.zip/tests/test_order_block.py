from core.market_structure import Candle, BreakEvent
from core.displacement import DisplacementEvent
from core.order_block import OrderBlockEngine


def c(i, o, h, l, close):
    return Candle(f"t{i}", o, h, l, close)


def test_bullish_order_block_is_found():
    candles = [
        c(0, 100, 101, 99, 100.5),
        c(1, 100.5, 101, 99.5, 100.0),  # bearish OB candidate
        c(2, 100, 104, 99.8, 103.8),    # bullish displacement
        c(3, 103.8, 104.5, 103, 104.2),
    ]

    displacement = DisplacementEvent(
        index=2,
        timestamp="t2",
        direction="BULLISH",
        body_ratio=0.95,
        range_ratio=2.0,
        close_location=0.95,
        atr_ratio=2.0,
        broke_structure=True,
        score=95.0,
    )
    brk = BreakEvent(2, "t2", "BULLISH", "BOS", 102.0, 103.8)

    result = OrderBlockEngine(min_score=60).analyze(
        candles, [displacement], [brk]
    )

    assert result.valid
    assert result.status == "CONFIRMED"
    assert result.selected["type"] == "BULLISH"
    assert result.selected["index"] == 1


def test_invalidated_order_block_is_rejected():
    candles = [
        c(0, 100, 101, 99, 100.5),
        c(1, 100.5, 101, 99.5, 100.0),
        c(2, 100, 104, 99.8, 103.8),
        c(3, 103.8, 104, 98.5, 98.8),  # closes below OB low
    ]

    displacement = DisplacementEvent(
        2, "t2", "BULLISH", 0.95, 2.0, 0.95, 2.0, True, 95.0
    )

    result = OrderBlockEngine(min_score=60).analyze(
        candles, [displacement]
    )

    assert not result.valid
    assert result.status == "NO_TRADE"
