from backtest import Backtester
from core.market_structure import Candle


def c(i, o, h, l, cl):
    return Candle(str(i), o, h, l, cl)


def test_limit_entry_must_be_touched_before_trade_is_counted():
    candles = [
        c(0, 110, 111, 109, 110),
        c(1, 110, 112, 108, 111),
        c(2, 111, 115, 110.5, 114),
    ]

    def signal(i, history):
        return {"direction": "BUY", "entry": 100, "stop_loss": 98, "take_profit": 120} if i == 0 else None

    result = Backtester().run(candles, signal)
    assert result.total_trades == 0


def test_limit_entry_fills_then_target_is_evaluated():
    candles = [
        c(0, 105, 106, 104, 105),
        c(1, 104, 105, 99, 100),
        c(2, 100, 108, 99.5, 107),
        c(3, 107, 111, 106, 110),
    ]

    def signal(i, history):
        return {"direction": "BUY", "entry": 100, "stop_loss": 98, "take_profit": 108} if i == 0 else None

    result = Backtester().run(candles, signal)
    assert result.total_trades == 1
    assert result.wins == 1
    assert result.trades[0]["entry_index"] == 1
    assert result.trades[0]["exit_index"] == 2


def test_pending_limit_is_cancelled_if_stop_is_breached_first():
    candles = [
        c(0, 105, 106, 104, 105),
        c(1, 104, 99.5, 97, 98),
        c(2, 98, 101, 97.5, 100),
        c(3, 100, 105, 99, 104),
    ]

    def signal(i, history):
        return {"direction": "BUY", "entry": 100, "stop_loss": 98, "take_profit": 108} if i == 0 else None

    result = Backtester().run(candles, signal)
    assert result.total_trades == 0
