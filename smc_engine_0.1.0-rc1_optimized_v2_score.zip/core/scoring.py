from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Mapping


@dataclass(frozen=True)
class ScoreBreakdown:
    market_structure: float
    liquidity: float
    displacement: float
    order_block: float
    fvg: float
    risk_reward: float
    total: float
    grade: str
    decision: str
    reasons: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


class ScoringEngine:
    """Scores a setup using fixed component weights totaling 100."""

    WEIGHTS = {
        "market_structure": 25.0,
        "liquidity": 15.0,
        "displacement": 10.0,
        "order_block": 15.0,
        "fvg": 15.0,
        "risk_reward": 20.0,
    }

    def __init__(self, min_score: float = 70.0) -> None:
        if not 0 <= min_score <= 100:
            raise ValueError("min_score must be between 0 and 100")
        self.min_score = min_score

    def score(self, setup: Mapping) -> ScoreBreakdown:
        values = {
            key: self._component_score(setup, key)
            for key in self.WEIGHTS
        }
        total = sum(values[key] for key in self.WEIGHTS)
        grade = self._grade(total)

        reasons: list[str] = []
        if values["market_structure"] >= 0.8 * self.WEIGHTS["market_structure"]:
            reasons.append("Market structure is strongly aligned.")
        else:
            reasons.append("Market structure is not fully aligned.")

        if setup.get("liquidity_sweep"):
            reasons.append("Liquidity sweep is confirmed.")
        else:
            reasons.append("No confirmed liquidity sweep.")

        if setup.get("displacement"):
            reasons.append("Displacement is confirmed.")
        else:
            reasons.append("Displacement confirmation is missing.")

        if setup.get("order_block"):
            reasons.append("A valid order block is present.")
        else:
            reasons.append("No valid order block is present.")

        if setup.get("fvg"):
            reasons.append("A usable FVG is present.")
        else:
            reasons.append("No usable FVG is present.")

        rr = float(setup.get("rr_tp1", 0.0) or 0.0)
        reasons.append(f"TP1 risk/reward is {rr:.2f}.")

        decision = "APPROVE" if total >= self.min_score else "REJECT"

        return ScoreBreakdown(
            market_structure=round(values["market_structure"], 2),
            liquidity=round(values["liquidity"], 2),
            displacement=round(values["displacement"], 2),
            order_block=round(values["order_block"], 2),
            fvg=round(values["fvg"], 2),
            risk_reward=round(values["risk_reward"], 2),
            total=round(total, 2),
            grade=grade,
            decision=decision,
            reasons=reasons,
        )

    def _component_score(self, setup: Mapping, key: str) -> float:
        weight = self.WEIGHTS[key]

        if key == "market_structure":
            confidence = float(setup.get("structure_confidence", 0.0) or 0.0)
            return weight * max(0.0, min(confidence / 100.0, 1.0))

        if key == "liquidity":
            return weight if setup.get("liquidity_sweep") else 0.0

        if key == "displacement":
            score = float(setup.get("displacement_score", 0.0) or 0.0)
            return weight * max(0.0, min(score / 100.0, 1.0))

        if key == "order_block":
            score = float(setup.get("order_block_score", 0.0) or 0.0)
            return weight * max(0.0, min(score / 100.0, 1.0))

        if key == "fvg":
            score = float(setup.get("fvg_score", 0.0) or 0.0)
            return weight * max(0.0, min(score / 100.0, 1.0))

        if key == "risk_reward":
            rr = float(setup.get("rr_tp1", 0.0) or 0.0)
            return weight * max(0.0, min(rr / 4.0, 1.0))

        return 0.0

    @staticmethod
    def _grade(total: float) -> str:
        if total >= 90:
            return "A"
        if total >= 80:
            return "B"
        if total >= 70:
            return "C"
        if total >= 60:
            return "D"
        return "F"
