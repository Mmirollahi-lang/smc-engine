from core.market_structure import Candle
from core.fvg import FVGEngine


def c(i, o, h, l, close):
    return Candle(f"t{i}", o, h, l, close)


def test_bullish_fvg_detected_and_unfilled():
    candles = [
        c(0, 100, 101, 99, 100),
        c(1, 100, 104, 100, 103),
        c(2, 103, 106, 102, 105),
    ]

    result = FVGEngine(min_gap_pct=0.005).analyze(candles)

    assert result.valid
    assert result.status == "CONFIRMED"
    assert result.selected["type"] == "BULLISH"
    assert not result.selected["filled"]


def test_filled_fvg_is_not_confirmed():
    candles = [
        c(0, 100, 101, 99, 100),
        c(1, 100, 104, 100, 103),
        c(2, 103, 106, 102, 105),
        c(3, 105, 105.5, 99, 100),
    ]

    result = FVGEngine(min_gap_pct=0.005).analyze(candles)

    assert result.status == "WAIT"
    assert not result.valid
